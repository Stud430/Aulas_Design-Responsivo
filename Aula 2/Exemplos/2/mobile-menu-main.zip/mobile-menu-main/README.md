# Mobile Menu

Fiz um menu mobile responsivo só com HTML e CSS // E por que usar JavaScript é melhor. [Veja mais](https://www.youtube.com/watch?v=5iGoLFkIVl4).
