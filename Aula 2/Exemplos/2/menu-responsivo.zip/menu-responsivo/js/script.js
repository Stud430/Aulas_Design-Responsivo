$(function () {


    //HEADER
    $(window).scroll(function () {
          if($(this).scrollTop() > 200)
          {
              if (!$('.main_header').hasClass('fixed'))
              {
                  $('.main_header').stop().addClass('fixed').css('top', '-100px').animate(
                      {
                          'top': '0px'
                      }, 500);
              }
          }
          else
          {
              $('.main_header').removeClass('fixed');
          }
    });


});

    $('.btn-mobile').click(function () {

        if (!$(this).hasClass('menu-ativo')) {
             $(this).addClass('menu-ativo');
             $('.controla-menu').slideDown(500);
        } else {
            $(this).removeClass('menu-ativo');
            $('.controla-menu').slideUp(400);
        }
    });